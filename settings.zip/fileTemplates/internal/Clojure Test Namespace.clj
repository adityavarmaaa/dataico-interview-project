(ns $NS_NAME
  (:require 
    [fulcro-spec.core :refer [specification assertions component =>]]
    [com.fulcrologic.guardrails.malli.fulcro-spec-helpers :refer [when-mocking! provided!]]
    [$TEST_SUBJECT_NS :as subj]))
